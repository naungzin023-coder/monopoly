package com.mmgames.monopoly;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    private AlertDialog dlg;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    // Back key: first close any open panel inside the game, otherwise ask before leaving.
    @Override
    public void onBackPressed() {
        if (dlg != null && dlg.isShowing()) return;
        web.evaluateJavascript("(function(){try{return backKey()}catch(e){return 0}})()", v -> {
            if ("1".equals(v)) return;
            askExit();
        });
    }

    private void askExit() {
        dlg = new AlertDialog.Builder(this)
            .setTitle("ဂိမ်းထဲကထွက်မလား?")
            .setMessage("ကစားနေသောပွဲကို အလိုအလျောက် သိမ်းထားပြီးဖြစ်သဖြင့် နောက်မှ ဆက်ကစားနိုင်ပါသည်။")
            .setPositiveButton("ထွက်မည်", (d, w) ->
                web.evaluateJavascript("try{saveG()}catch(e){}", r -> finish()))
            .setNegativeButton("မထွက်ပါ", null)
            .show();
    }
}
