မြို့တော်ကုန်သည် – Android project

နည်း (၁) Android Studio:
  File > Open > ဒီ folder ကိုရွေး > Build > Build APK(s)
  APK: app/build/outputs/apk/debug/app-debug.apk

နည်း (၂) GitHub (ကွန်ပျူတာမလို):
  GitHub မှာ repository အသစ်ဖွင့် > ဒီ folder ထဲက ဖိုင်အားလုံး upload
  Actions tab > Build APK > run ပြီးရင် Artifacts မှ MyanmarMonopoly-apk ကို download
  (zip ထဲက app-debug.apk ကို ဖုန်းမှာ install)
